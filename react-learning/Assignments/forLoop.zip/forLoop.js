var ecommerceProducts = [
    {        "id": 1,           "name": "Laptop",        "price": 999.99,        "category": "Electronics"    },  
    {        "id": 2,        "name": "Smartphone",        "price": 699.99,        "category": "Electronics"}];


    for (i=0; i<ecommerceProducts.length; i++) {
        console.log("E-commerce Products:", ecommerceProducts[i].id, ecommerceProducts[i].name, ecommerceProducts[i].price, ecommerceProducts[i].category);
    };
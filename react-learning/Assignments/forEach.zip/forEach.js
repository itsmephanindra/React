var products=[
    {name:"laptop",price:3000,brand:"lenovo",color:"silver"},
    {name:"phone",price:1000,brand:"iphone",color:"gold"},
    {name:"watch",price:300,brand:"casio",color:"black"},
    {name:"sunglass",price:200,brand:"rays",color:"black"},
    {name:"camera",price:500,brand:"canon",color:"gray"},
];

products.forEach(product => {
    console.log(product.name);
}
)

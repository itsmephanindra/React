var ecommerceProducts = [
    {        "id": 1,           "name": "Laptop",        "price": 999.99,        "category": "Electronics"    },  
    {        "id": 2,        "name": "Smartphone",        "price": 699.99,        "category": "Electronics"}];

    var facebookFriends = [
    {        "id": 1,        "name": "Alice",        "email": "alice@example.com",        "age": 25    },
    {        "id": 2,        "name": "Bob",        "email": "bob@example.com",        "age": 30    }];

    var youtubeVideos = [
    {        "id": 1,        "title": "JavaScript Tutorial",        "duration": "15:30",        "views": 100000    },
    {        "id": 2,        "title": "Learn Python",        "duration": "20:45",        "views": 150000    }];

    var email1 = "alice@example.com";
    var email2 = "bob@example.com";
    var userName1 = "Alice";
    var userName2 = "Bob";
    var age1 = 25;
    var age2 = 17;

    console.log("Emails are equal: " + (email1 === email2));
    console.log("User names are equal: " + (userName1 === userName2));
    console.log("Is age1 greater than 18: " + (age1 > 18));
    console.log("Is age2 greater than 18: " + (age2 > 18));
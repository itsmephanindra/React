var isUserLogged="no"

if (isUserLogged=="yes"){
    console.log("User is logged in");
}
else{
    console.log("User is not logged in");
}
import { isMailValid,loopArray,currentDate} from "./util.js";

var array1=[1,2,3,4,5]


isMailValid("abc");
isMailValid("abcdefgh");
loopArray(array1);
currentDate();